const { getClient } = require("./_neon");

exports.handler = async (event) => {
  if (event.httpMethod !== "POST") return { statusCode: 405, body: "Method Not Allowed" };

  const sql = getClient();

  try {
    const b = JSON.parse(event.body || "{}");

    // minimal validation
    const name = (b.name || "").toString().trim();
    const brand = (b.brand || "").toString().trim();
    const model = (b.model || "").toString().trim();
    const service = (b.service || "").toString().trim();
    const location = (b.location || "").toString().trim();
    const time = (b.time || "").toString().trim();
    const date = b.date ? new Date(b.date) : null;
    const dirtiness = Number(b.dirtiness);

    if (!name || !brand || !model || !service || !location || !time || !date || !Number.isFinite(dirtiness)) {
      return { statusCode: 400, body: "Missing required fields" };
    }

    const addons = b.addons || {};
    const estimated_price = b.estimatedPrice === null || b.estimatedPrice === undefined ? null : Number(b.estimatedPrice);

    const rows = await sql`
      INSERT INTO public.bookings
        (name, phone, brand, model, service, dirtiness, booked_date, booked_time, location, notes, addons_json, estimated_price)
      VALUES
        (${name},
         ${b.phone || null},
         ${brand},
         ${model},
         ${service},
         ${dirtiness},
         ${date.toISOString()},
         ${time},
         ${location},
         ${b.notes || null},
         ${JSON.stringify(addons)}::jsonb,
         ${estimated_price})
      RETURNING id
    `;

    return {
      statusCode: 200,
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ ok: true, id: rows[0].id }),
    };
  } catch (err) {
    return { statusCode: 500, body: "Server error" };
  }
};
