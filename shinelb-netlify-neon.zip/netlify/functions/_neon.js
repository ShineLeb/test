const { neon } = require("@neondatabase/serverless");

function getClient() {
  const url = process.env.DATABASE_URL;
  if (!url) {
    throw new Error("Missing DATABASE_URL env var (Neon connection string).");
  }
  return neon(url);
}

module.exports = { getClient };
