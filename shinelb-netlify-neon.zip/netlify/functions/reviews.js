const { getClient } = require("./_neon");

exports.handler = async (event) => {
  const sql = getClient();

  try {
    if (event.httpMethod === "GET") {
      const rows = await sql`
        SELECT id, name, rating, review, created_at
        FROM public.reviews
        ORDER BY created_at DESC
        LIMIT 20
      `;
      return {
        statusCode: 200,
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify(rows),
      };
    }

    if (event.httpMethod === "POST") {
      const body = JSON.parse(event.body || "{}");
      const name = (body.name || "").toString().trim();
      const review = (body.review || "").toString().trim();
      const rating = Number(body.rating);

      if (!name || !review || !Number.isFinite(rating) || rating < 1 || rating > 5) {
        return { statusCode: 400, body: "Invalid payload" };
      }

      const rows = await sql`
        INSERT INTO public.reviews (name, rating, review)
        VALUES (${name}, ${rating}, ${review})
        RETURNING id, name, rating, review, created_at
      `;

      return {
        statusCode: 200,
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify(rows[0]),
      };
    }

    return { statusCode: 405, body: "Method Not Allowed" };
  } catch (err) {
    return { statusCode: 500, body: "Server error" };
  }
};
