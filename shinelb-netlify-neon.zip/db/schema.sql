-- Neon/Postgres schema for ShineLeb
-- Run this in Neon SQL Editor (or any Postgres client)

CREATE EXTENSION IF NOT EXISTS pgcrypto;

CREATE TABLE IF NOT EXISTS public.reviews (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  name TEXT NOT NULL,
  rating INTEGER NOT NULL CHECK (rating >= 1 AND rating <= 5),
  review TEXT NOT NULL,
  created_at TIMESTAMPTZ NOT NULL DEFAULT now()
);

CREATE TABLE IF NOT EXISTS public.bookings (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  created_at TIMESTAMPTZ NOT NULL DEFAULT now(),
  name TEXT NOT NULL,
  phone TEXT NULL,
  brand TEXT NOT NULL,
  model TEXT NOT NULL,
  service TEXT NOT NULL,
  dirtiness INTEGER NOT NULL,
  booked_date TIMESTAMPTZ NOT NULL,
  booked_time TEXT NOT NULL,
  location TEXT NOT NULL,
  notes TEXT NULL,
  addons_json JSONB NOT NULL DEFAULT '{}'::jsonb,
  estimated_price NUMERIC NULL
);

CREATE INDEX IF NOT EXISTS idx_reviews_created_at ON public.reviews (created_at DESC);
CREATE INDEX IF NOT EXISTS idx_bookings_date ON public.bookings (booked_date DESC);
