import { useState, useEffect } from "react";
import { motion } from "framer-motion";
import { Star, Droplets, Send, CheckCircle2 } from "lucide-react";
import { Input } from "@/components/ui/input";
import { Textarea } from "@/components/ui/textarea";
import { useToast } from "@/hooks/use-toast";
import { fetchReviews as apiFetchReviews, submitReview } from "@/lib/api";

interface Review {
  id: string;
  name: string;
  rating: number;
  review: string;
  created_at: string;
}

const StarDisplay = ({ rating }: { rating: number }) => (
  <div className="flex gap-0.5">
    {[1, 2, 3, 4, 5].map((star) => (
      <Star
        key={star}
        className={`w-4 h-4 ${star <= rating ? "fill-primary text-primary" : "text-border"}`}
      />
    ))}
  </div>
);

const Testimonials = () => {
  const [name, setName] = useState("");
  const [review, setReview] = useState("");
  const [rating, setRating] = useState(0);
  const [hoveredStar, setHoveredStar] = useState(0);
  const [submitted, setSubmitted] = useState(false);
  const [reviews, setReviews] = useState<Review[]>([]);
  const { toast } = useToast();

  useEffect(() => {
    fetchReviews();
  }, []);

  const fetchReviews = async () => {
    try {
      const data = await apiFetchReviews();
      setReviews(data);
    } catch (e) {
      // silent fail; UI still loads
    }
  };

  const handleSubmit = async () => {
    if (!name.trim() || !review.trim() || rating === 0) {
      toast({
        title: "Missing info",
        description: "Please fill in your name, rating, and review.",
        variant: "destructive",
      });
      return;
    }

    try {
      await submitReview({
        name: name.trim(),
        rating,
        review: review.trim(),
      });
    } catch (e) {
      toast({ title: "Error", description: "Could not submit review.", variant: "destructive" });
      return;
    }

    setSubmitted(true);
    toast({ title: "Thank you!", description: "Your review has been submitted." });
    fetchReviews();
  };

  const handleReset = () => {
    setName("");
    setReview("");
    setRating(0);
    setSubmitted(false);
  };

  return (
    <section className="py-24 bg-card relative overflow-hidden" id="reviews">
      <div className="absolute top-10 left-10 w-24 h-24 rounded-full bg-primary/5 blur-2xl" />
      <div className="absolute bottom-10 right-10 w-20 h-20 rounded-full bg-accent/5 blur-xl" />
      <motion.div
        className="absolute top-1/4 right-[10%] w-5 h-5 rounded-full bg-primary/10"
        animate={{ y: [0, -12, 0], opacity: [0.3, 0.6, 0.3] }}
        transition={{ duration: 4, repeat: Infinity }}
      />
      <div className="absolute top-0 left-0 right-0 h-px bg-gradient-to-r from-transparent via-primary/20 to-transparent" />

      <div className="container mx-auto px-6 relative z-10">
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true }}
          className="text-center mb-12"
        >
          <div className="inline-flex items-center gap-2 px-3 py-1 rounded-full bg-primary/10 text-primary text-sm font-medium mb-4">
            <Droplets className="w-3.5 h-3.5" />
            Reviews
          </div>
          <h2 className="text-4xl md:text-5xl font-display font-bold mb-4">
            Leave a <span className="text-gradient-blue">Review</span>
          </h2>
          <p className="text-muted-foreground max-w-lg mx-auto">
            Had your car detailed by ShineLeb? We'd love to hear your feedback!
          </p>
        </motion.div>

        {reviews.length > 0 && (
          <div className="max-w-2xl mx-auto mb-12 space-y-4">
            {reviews.map((r) => (
              <motion.div
                key={r.id}
                initial={{ opacity: 0, y: 10 }}
                whileInView={{ opacity: 1, y: 0 }}
                viewport={{ once: true }}
                className="bg-background rounded-xl border border-border p-5"
              >
                <div className="flex items-center justify-between mb-2">
                  <span className="font-display font-semibold text-foreground">{r.name}</span>
                  <StarDisplay rating={r.rating} />
                </div>
                <p className="text-muted-foreground text-sm">{r.review}</p>
              </motion.div>
            ))}
          </div>
        )}

        {submitted ? (
          <motion.div
            initial={{ opacity: 0, scale: 0.95 }}
            animate={{ opacity: 1, scale: 1 }}
            className="max-w-md mx-auto text-center py-12"
          >
            <div className="w-20 h-20 mx-auto rounded-full bg-accent/10 flex items-center justify-center mb-6">
              <CheckCircle2 className="w-10 h-10 text-accent" />
            </div>
            <h3 className="text-2xl font-display font-bold text-foreground mb-3">Thanks, {name.trim()}!</h3>
            <p className="text-muted-foreground mb-8">Your review means a lot to us.</p>
            <button
              onClick={handleReset}
              className="px-6 py-3 rounded-full border border-border text-foreground font-medium hover:bg-background transition-colors"
            >
              Leave Another
            </button>
          </motion.div>
        ) : (
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true }}
            className="max-w-md mx-auto"
          >
            <div className="bg-background rounded-2xl shadow-soft border border-border p-8 space-y-5">
              {/* Star Rating */}
              <div>
                <label className="block text-sm font-medium text-foreground mb-2">Your Rating</label>
                <div className="flex gap-1">
                  {[1, 2, 3, 4, 5].map((star) => (
                    <button
                      key={star}
                      type="button"
                      onClick={() => setRating(star)}
                      onMouseEnter={() => setHoveredStar(star)}
                      onMouseLeave={() => setHoveredStar(0)}
                      className="transition-transform hover:scale-110"
                    >
                      <Star
                        className={`w-7 h-7 transition-colors ${
                          star <= (hoveredStar || rating)
                            ? "fill-primary text-primary"
                            : "text-border"
                        }`}
                      />
                    </button>
                  ))}
                </div>
              </div>

              {/* Name */}
              <div>
                <label className="block text-sm font-medium text-foreground mb-1.5">Your Name</label>
                <Input
                  placeholder="Enter your name"
                  value={name}
                  onChange={(e) => setName(e.target.value)}
                  maxLength={100}
                  className="rounded-xl"
                />
              </div>

              {/* Review */}
              <div>
                <label className="block text-sm font-medium text-foreground mb-1.5">Your Review</label>
                <Textarea
                  placeholder="Tell us about your experience..."
                  value={review}
                  onChange={(e) => setReview(e.target.value)}
                  maxLength={500}
                  rows={4}
                  className="rounded-xl resize-none"
                />
              </div>

              {/* Submit */}
              <button
                onClick={handleSubmit}
                className="w-full flex items-center justify-center gap-2 px-8 py-4 bg-gradient-blue text-primary-foreground font-semibold rounded-full shadow-blue hover:scale-[1.02] active:scale-100 transition-transform duration-200"
              >
                <Send className="w-4 h-4" />
                Submit Review
              </button>
            </div>
          </motion.div>
        )}
      </div>
    </section>
  );
};

export default Testimonials;
