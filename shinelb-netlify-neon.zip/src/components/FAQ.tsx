import { motion } from "framer-motion";
import { HelpCircle } from "lucide-react";
import {
  Accordion,
  AccordionContent,
  AccordionItem,
  AccordionTrigger,
} from "@/components/ui/accordion";

const faqs = [
  {
    q: "Do you come to my location?",
    a: "Yes! ShineLeb is a fully mobile service. We come to your home, office, or wherever your car is parked — anywhere in Lebanon.",
  },
  {
    q: "How long does a detailing session take?",
    a: "It depends on the service and car size. A standard interior or exterior service takes around 1.5 to 2 hours. A full detail on a larger vehicle (SUV, 4x4, truck) can take up to 4 hours. We always prioritize quality over speed.",
  },
  {
    q: "What's the difference between Interior, Exterior, and Full Detail?",
    a: "Interior covers seats, dashboard, carpets, air freshening, and surface protection. Exterior includes hand wash, rims, tire shine, and plastics restoration. Full Detail combines both for a complete showroom finish.",
  },
  {
    q: "Do I need to provide water or electricity?",
    a: "We bring all our own water supply — no need to worry about that. As for electricity, if you can provide access to a power outlet, that's a bonus and helps us work more efficiently, but it's not a necessity — we can manage without it.",
  },
  {
    q: "How do I book?",
    a: "Simply scroll to the booking section on this page, pick your date and time (Mon–Sat, 8 AM – 8 PM), select your car brand and model, choose your service, and we'll confirm via WhatsApp or phone call.",
  },
  {
    q: "What areas in Lebanon do you cover?",
    a: "We cover all of Lebanon — Beirut, Mount Lebanon, North, South, and Bekaa. Just enter your location when booking.",
  },
  {
    q: "What is Ceramic Spray Protection?",
    id: "ceramic-spray",
    a: "Ceramic Spray Protection is a premium add-on that applies a thin, durable layer of ceramic coating over your car's paint. It adds a deep glossy shine, repels water and dirt, and provides UV protection — helping your car stay cleaner for longer between washes. It's especially recommended after a full detail to lock in that showroom finish.",
  },
  {
    q: "Do you offer wax or oil change services?",
    a: "Not yet! We currently specialize in detailing only. Wax coating, oil changes, and other mechanical services are not available at the moment — but stay tuned, we may add them in the future.",
  },
];

const FAQ = () => {
  return (
    <section className="py-24 bg-background relative overflow-hidden" id="faq">
      <div className="absolute top-10 right-10 w-24 h-24 rounded-full bg-primary/5 blur-2xl" />
      <div className="absolute bottom-10 left-10 w-20 h-20 rounded-full bg-accent/5 blur-xl" />
      <motion.div
        className="absolute top-1/3 left-[10%] w-5 h-5 rounded-full border-2 border-dashed border-primary/10"
        animate={{ y: [0, -10, 0], rotate: [0, 180, 360] }}
        transition={{ duration: 5, repeat: Infinity }}
      />
      <div className="absolute top-0 left-0 right-0 h-px bg-gradient-to-r from-transparent via-primary/20 to-transparent" />

      <div className="container mx-auto px-6 relative z-10">
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true }}
          className="text-center mb-12"
        >
          <div className="inline-flex items-center gap-2 px-3 py-1 rounded-full bg-primary/10 text-primary text-sm font-medium mb-4">
            <HelpCircle className="w-3.5 h-3.5" />
            FAQ
          </div>
          <h2 className="text-4xl md:text-5xl font-display font-bold mb-4">
            Common <span className="text-gradient-blue">Questions</span>
          </h2>
          <p className="text-muted-foreground max-w-lg mx-auto">
            Everything you need to know about our service.
          </p>
        </motion.div>

        <motion.div
          initial={{ opacity: 0, y: 20 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true }}
          className="max-w-2xl mx-auto"
        >
          <Accordion type="single" collapsible className="space-y-3">
            {faqs.map((faq, i) => (
              <AccordionItem
                key={i}
                value={faq.id || `item-${i}`}
                className="bg-card rounded-xl border border-border px-6 data-[state=open]:border-primary/30 transition-colors"
              >
                <AccordionTrigger className="text-left text-foreground hover:no-underline">
                  {faq.q}
                </AccordionTrigger>
                <AccordionContent className="text-muted-foreground">
                  {faq.a}
                </AccordionContent>
              </AccordionItem>
            ))}
          </Accordion>
        </motion.div>
      </div>
    </section>
  );
};

export default FAQ;
