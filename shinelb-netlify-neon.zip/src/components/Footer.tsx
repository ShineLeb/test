import { Droplets, Mail, Instagram, Phone } from "lucide-react";

const Footer = () => {
  return (
    <footer className="py-16 bg-card border-t border-border relative overflow-hidden">
      {/* Decorative */}
      <div className="absolute top-0 left-1/4 w-32 h-32 rounded-full bg-primary/5 blur-3xl" />
      <div className="absolute bottom-0 right-1/4 w-24 h-24 rounded-full bg-accent/5 blur-2xl" />

      <div className="container mx-auto px-6 relative z-10">
        <div className="grid grid-cols-1 md:grid-cols-3 gap-10">
          {/* Brand */}
          <div>
            <a href="#" className="flex items-center gap-1 mb-4">
              <Droplets className="w-6 h-6 text-primary" />
              <h3 className="text-xl font-display font-bold">
                Shine<span className="text-gradient-blue">Leb</span>
              </h3>
            </a>
            <p className="text-muted-foreground text-sm leading-relaxed">
              Lebanon's mobile car detailing service. We come to you — anywhere in the country. Monday–Saturday, 8 AM – 8 PM.
            </p>
          </div>

          {/* Quick Links */}
          <div>
            <h4 className="font-display font-semibold text-foreground mb-4">Quick Links</h4>
            <div className="space-y-2">
              <a href="#services" className="block text-muted-foreground hover:text-primary text-sm transition-colors">Services</a>
              <a href="#pricing" className="block text-muted-foreground hover:text-primary text-sm transition-colors">Pricing</a>
              <a href="#booking" className="block text-muted-foreground hover:text-primary text-sm transition-colors">Book Now</a>
              <a href="#faq" className="block text-muted-foreground hover:text-primary text-sm transition-colors">FAQ</a>
              <a href="#reviews" className="block text-muted-foreground hover:text-primary text-sm transition-colors">Reviews</a>
            </div>
          </div>

          {/* Contact */}
          <div>
            <h4 className="font-display font-semibold text-foreground mb-4">Contact Us</h4>
            <div className="space-y-3">
              <a
                href="mailto:customersupport@shineleb.com"
                className="flex items-center gap-2 text-muted-foreground hover:text-primary text-sm transition-colors"
              >
                <Mail className="w-4 h-4" />
                customersupport@shineleb.com
              </a>
              <a
                href="mailto:sales@shineleb.com"
                className="flex items-center gap-2 text-muted-foreground hover:text-primary text-sm transition-colors"
              >
                <Mail className="w-4 h-4" />
                sales@shineleb.com
              </a>
              <div className="flex items-center gap-3 pt-2">
                <a
                  href="https://wa.me/96179163149"
                  target="_blank"
                  rel="noopener noreferrer"
                  className="w-9 h-9 rounded-full bg-primary/10 flex items-center justify-center text-primary hover:bg-primary hover:text-primary-foreground transition-colors"
                  aria-label="WhatsApp"
                >
                  <svg className="w-4 h-4" fill="currentColor" viewBox="0 0 24 24"><path d="M17.472 14.382c-.297-.149-1.758-.867-2.03-.967-.273-.099-.471-.148-.67.15-.197.297-.767.966-.94 1.164-.173.199-.347.223-.644.075-.297-.15-1.255-.463-2.39-1.475-.883-.788-1.48-1.761-1.653-2.059-.173-.297-.018-.458.13-.606.134-.133.298-.347.446-.52.149-.174.198-.298.298-.497.099-.198.05-.371-.025-.52-.075-.149-.669-1.612-.916-2.207-.242-.579-.487-.5-.669-.51-.173-.008-.371-.01-.57-.01-.198 0-.52.074-.792.372-.272.297-1.04 1.016-1.04 2.479 0 1.462 1.065 2.875 1.213 3.074.149.198 2.096 3.2 5.077 4.487.709.306 1.262.489 1.694.625.712.227 1.36.195 1.871.118.571-.085 1.758-.719 2.006-1.413.248-.694.248-1.289.173-1.413-.074-.124-.272-.198-.57-.347m-5.421 7.403h-.004a9.87 9.87 0 01-5.031-1.378l-.361-.214-3.741.982.998-3.648-.235-.374a9.86 9.86 0 01-1.51-5.26c.001-5.45 4.436-9.884 9.888-9.884 2.64 0 5.122 1.03 6.988 2.898a9.825 9.825 0 012.893 6.994c-.003 5.45-4.437 9.884-9.885 9.884m8.413-18.297A11.815 11.815 0 0012.05 0C5.495 0 .16 5.335.157 11.892c0 2.096.547 4.142 1.588 5.945L.057 24l6.305-1.654a11.882 11.882 0 005.683 1.448h.005c6.554 0 11.89-5.335 11.893-11.893a11.821 11.821 0 00-3.48-8.413z"/></svg>
                </a>
                <a
                  href="https://www.instagram.com/shinelebdetailing"
                  target="_blank"
                  rel="noopener noreferrer"
                  className="w-9 h-9 rounded-full bg-primary/10 flex items-center justify-center text-primary hover:bg-primary hover:text-primary-foreground transition-colors"
                  aria-label="Instagram"
                >
                  <Instagram className="w-4 h-4" />
                </a>
                <a
                  href="tel:+96171085680"
                  className="w-9 h-9 rounded-full bg-primary/10 flex items-center justify-center text-primary hover:bg-primary hover:text-primary-foreground transition-colors"
                  aria-label="Call us"
                >
                  <Phone className="w-4 h-4" />
                </a>
              </div>
            </div>
          </div>
        </div>

        <div className="mt-10 pt-6 border-t border-border text-center">
          <p className="text-muted-foreground text-xs">
            © {new Date().getFullYear()} ShineLeb. All rights reserved.
          </p>
        </div>
      </div>
    </footer>
  );
};

export default Footer;
