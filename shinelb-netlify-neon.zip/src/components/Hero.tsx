import { motion } from "framer-motion";
import { Droplets, ChevronDown, Sparkles, Star } from "lucide-react";
import heroImage from "@/assets/hero-car-new.jpg";

const Bubble = ({ size, left, delay }: { size: number; left: string; delay: number }) => (
  <motion.div
    className="absolute bottom-0 rounded-full bg-white/15 border border-white/10"
    style={{ width: size, height: size, left }}
    animate={{
      y: [0, -120],
      opacity: [0.7, 0],
      scale: [1, 0.5],
    }}
    transition={{ duration: 3 + Math.random() * 3, repeat: Infinity, delay, ease: "easeOut" }}
  />
);

const FloatingParticle = ({ top, left, delay, size }: { top: string; left: string; delay: number; size: number }) => (
  <motion.div
    className="absolute rounded-full bg-white/20"
    style={{ top, left, width: size, height: size }}
    animate={{
      y: [0, -20, 0],
      opacity: [0.2, 0.6, 0.2],
      scale: [1, 1.3, 1],
    }}
    transition={{ duration: 4, repeat: Infinity, delay, ease: "easeInOut" }}
  />
);

const Hero = () => {
  return (
    <section className="relative min-h-screen flex items-center justify-center overflow-hidden">
      {/* Background Image */}
      <div className="absolute inset-0">
        <img
          src={heroImage}
          alt="Premium car detailing service in Lebanon"
          className="w-full h-full object-cover"
          loading="eager"
        />
        <div className="absolute inset-0 bg-gradient-to-br from-[hsl(220_15%_8%/0.88)] via-[hsl(220_15%_10%/0.7)] to-[hsl(82_85%_45%/0.15)]" />
        <div className="absolute inset-0 bg-gradient-to-t from-[hsl(220_15%_8%/0.5)] via-transparent to-transparent" />
      </div>

      {/* Floating bubbles */}
      <div className="absolute inset-0 pointer-events-none overflow-hidden">
        <Bubble size={20} left="10%" delay={0} />
        <Bubble size={14} left="25%" delay={1.5} />
        <Bubble size={24} left="45%" delay={0.8} />
        <Bubble size={16} left="65%" delay={2.2} />
        <Bubble size={12} left="80%" delay={1} />
        <Bubble size={18} left="90%" delay={3} />
        <Bubble size={10} left="50%" delay={0.3} />
        <Bubble size={22} left="35%" delay={2.8} />
        <Bubble size={8} left="70%" delay={1.8} />
        <Bubble size={15} left="5%" delay={3.5} />
      </div>

      {/* Floating particles */}
      <div className="absolute inset-0 pointer-events-none">
        <FloatingParticle top="20%" left="15%" delay={0} size={6} />
        <FloatingParticle top="35%" left="75%" delay={1.2} size={4} />
        <FloatingParticle top="60%" left="25%" delay={2.4} size={5} />
        <FloatingParticle top="45%" left="85%" delay={0.8} size={3} />
        <FloatingParticle top="70%" left="55%" delay={1.6} size={7} />
        <FloatingParticle top="25%" left="90%" delay={3} size={4} />
      </div>

      {/* Decorative sparkle dots */}
      <div className="absolute inset-0 pointer-events-none">
        <motion.div
          className="absolute top-1/4 left-[15%] w-2 h-2 rounded-full bg-white/30"
          animate={{ opacity: [0.2, 0.8, 0.2], scale: [1, 1.5, 1] }}
          transition={{ duration: 3, repeat: Infinity }}
        />
        <motion.div
          className="absolute top-1/3 right-[20%] w-1.5 h-1.5 rounded-full bg-white/20"
          animate={{ opacity: [0.1, 0.6, 0.1], scale: [1, 1.4, 1] }}
          transition={{ duration: 3, repeat: Infinity, delay: 1 }}
        />
        <motion.div
          className="absolute bottom-1/3 left-[30%] w-1 h-1 rounded-full bg-white/25"
          animate={{ opacity: [0.15, 0.7, 0.15] }}
          transition={{ duration: 2.5, repeat: Infinity, delay: 2 }}
        />
      </div>

      {/* Glow ring behind content */}
      <div className="absolute top-1/2 left-1/2 -translate-x-1/2 -translate-y-1/2 w-[600px] h-[600px] rounded-full bg-[hsl(82_85%_45%/0.04)] blur-[100px] pointer-events-none" />

      {/* Content */}
      <div className="relative z-10 container mx-auto px-6 text-center">
        <motion.div
          initial={{ opacity: 0, y: 30 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.8, ease: "easeOut" }}
        >
          {/* Ramadan Badge */}
          <motion.div
            initial={{ opacity: 0, scale: 0.8 }}
            animate={{ opacity: 1, scale: 1 }}
            transition={{ duration: 0.6, delay: 0.2 }}
            className="inline-flex items-center gap-2 px-5 py-2.5 rounded-full bg-gradient-to-r from-[hsl(82_85%_45%/0.2)] to-[hsl(82_90%_55%/0.15)] backdrop-blur-md border border-[hsl(82_85%_45%/0.3)] mb-6 shadow-blue"
          >
            <Star className="w-4 h-4 text-primary fill-primary" />
            <span className="text-white/90 text-sm font-semibold tracking-wide">Ramadan Special Offers</span>
            <Star className="w-4 h-4 text-primary fill-primary" />
          </motion.div>

          <div className="inline-flex items-center gap-2 px-4 py-2 rounded-full bg-white/10 backdrop-blur-sm border border-white/20 mb-6">
            <Droplets className="w-4 h-4 text-white" />
            <span className="text-white/90 text-sm font-medium tracking-wide">Mobile Detailing · Lebanon</span>
          </div>
          <h1 className="text-5xl md:text-7xl lg:text-8xl font-display font-800 leading-[0.95] mb-6">
            <span className="text-white">Fresh</span>{" "}
            <span className="text-white">Clean</span>
            <br />
            <span className="text-gradient-blue">Every Time</span>
          </h1>
          <p className="text-white/70 text-lg md:text-xl max-w-xl mx-auto mb-10 font-light">
            One complete service. We come to you — anywhere in Lebanon. Interior, exterior & more.
          </p>
        </motion.div>

        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.8, delay: 0.3 }}
          className="flex flex-col sm:flex-row gap-4 justify-center"
        >
          <a
            href="#booking"
            className="inline-flex items-center justify-center gap-2 px-8 py-4 bg-gradient-blue text-primary-foreground font-semibold rounded-full shadow-blue hover:scale-105 transition-transform duration-300"
          >
            <Sparkles className="w-5 h-5" />
            Book Now
          </a>
          <a
            href="#pricing"
            className="inline-flex items-center justify-center px-8 py-4 border border-white/30 text-white font-semibold rounded-full hover:bg-white/10 backdrop-blur-sm transition-colors duration-300"
          >
            View Pricing
          </a>
        </motion.div>
      </div>

      {/* Scroll indicator */}
      <motion.div
        className="absolute bottom-8 left-1/2 -translate-x-1/2"
        animate={{ y: [0, 10, 0] }}
        transition={{ duration: 2, repeat: Infinity }}
      >
        <ChevronDown className="w-6 h-6 text-white/40" />
      </motion.div>
    </section>
  );
};

export default Hero;
