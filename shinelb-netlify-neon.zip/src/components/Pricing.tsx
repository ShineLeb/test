import { motion } from "framer-motion";
import { Check, Sparkles, Star, Tag, ArrowRight } from "lucide-react";
import interiorImg from "@/assets/interior-detail.jpg";
import exteriorImg from "@/assets/exterior-detail.jpg";
import fullImg from "@/assets/full-detail.jpg";

const services = [
  {
    name: "Interior Detail",
    desc: "Deep clean inside your car",
    image: interiorImg,
    prices: {
      sedan: "$62.99 – $82.99",
      suv: "$82.99 – $102.99",
      "4x4": "$102.99 – $120.99",
    },
    originalPrices: {
      sedan: "$89.99 – $109.99",
      suv: "$109.99 – $139.99",
      "4x4": "$139.99 – $159.99",
    },
    discount: "Up to 30% OFF",
    features: [
      "Full vacuum (seats, carpets, trunk)",
      "Steam cleaning (dash, panels, vents)",
      "Fabric shampoo (if needed)",
      "Leather cleaning + conditioning",
      "Plastic cleaning & light dressing",
      "Interior glass cleaned",
      "Light fragrance",
    ],
  },
  {
    name: "Exterior Detail",
    desc: "Shine on the outside",
    image: exteriorImg,
    prices: {
      sedan: "$32.99 – $52.99",
      suv: "$42.99 – $62.99",
      "4x4": "$52.99 – $72.99",
    },
    originalPrices: {
      sedan: "$49.99 – $69.99",
      suv: "$59.99 – $84.99",
      "4x4": "$74.99 – $99.99",
    },
    discount: "Up to 35% OFF",
    features: [
      "Pre-wash treatment",
      "Full hand wash",
      "Rims deep cleaned",
      "Tire cleaning + tire shine",
      "Exterior plastics restored",
      "Exterior glass cleaned",
    ],
  },
  {
    name: "Full Detail",
    desc: "Complete showroom finish",
    image: fullImg,
    prices: {
      sedan: "$84.99 – $104.99",
      suv: "$109.99 – $129.99",
      "4x4": "$134.99 – $154.99",
    },
    originalPrices: {
      sedan: "$119.99 – $149.99",
      suv: "$149.99 – $179.99",
      "4x4": "$179.99 – $209.99",
    },
    discount: "Up to 30% OFF",
    popular: true,
    features: [
      "Everything in Interior Detail",
      "Everything in Exterior Detail",
      "Full refresh finish",
    ],
  },
];

const addOns = [
  { name: "Pet Hair Removal", price: "$22.99", originalPrice: "$34.99" },
  { name: "Ceramic Spray Protection", price: "$32.99", originalPrice: "$49.99", hasFaqLink: true },
  { name: "Headlight Restoration", price: "$34.99", originalPrice: "$54.99" },
];

const sizeLabels = [
  { key: "sedan", label: "Sedan" },
  { key: "suv", label: "SUV / Crossover" },
  { key: "4x4", label: "4x4 / Truck" },
] as const;

const Pricing = () => {
  return (
    <section className="py-24 bg-background relative overflow-hidden" id="pricing">
      {/* Decorative elements */}
      <div className="absolute top-0 left-1/4 w-40 h-40 rounded-full bg-primary/5 blur-3xl" />
      <div className="absolute bottom-0 right-1/4 w-32 h-32 rounded-full bg-accent/5 blur-2xl" />
      <motion.div
        className="absolute top-20 right-10 w-8 h-8 rounded-full border-2 border-dashed border-primary/15"
        animate={{ x: [0, 8, -8, 0], rotate: [0, 180, 360] }}
        transition={{ duration: 6, repeat: Infinity, ease: "easeInOut" }}
      />
      <motion.div
        className="absolute bottom-20 left-10 w-6 h-6 rounded-full bg-primary/10"
        animate={{ y: [0, -15, 0], opacity: [0.3, 0.7, 0.3] }}
        transition={{ duration: 4, repeat: Infinity }}
      />
      {/* Gradient line accents */}
      <div className="absolute top-0 left-0 right-0 h-px bg-gradient-to-r from-transparent via-primary/20 to-transparent" />
      <div className="absolute bottom-0 left-0 right-0 h-px bg-gradient-to-r from-transparent via-primary/20 to-transparent" />

      <div className="container mx-auto px-6 relative z-10">
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true }}
          className="text-center mb-16"
        >
          {/* Ramadan Banner */}
          <motion.div
            initial={{ opacity: 0, y: -10 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true }}
            className="inline-block mb-6"
          >
            <div className="relative px-8 py-3 rounded-2xl bg-gradient-to-r from-primary/10 via-accent/10 to-primary/10 border border-primary/20">
              <div className="absolute -top-1 -left-1 w-3 h-3 rounded-full bg-primary/40 animate-pulse" />
              <div className="absolute -top-1 -right-1 w-3 h-3 rounded-full bg-primary/40 animate-pulse" />
              <div className="absolute -bottom-1 -left-1 w-3 h-3 rounded-full bg-primary/40 animate-pulse" />
              <div className="absolute -bottom-1 -right-1 w-3 h-3 rounded-full bg-primary/40 animate-pulse" />
              <div className="flex items-center gap-3">
                <Star className="w-5 h-5 text-primary fill-primary" />
                <div>
                  <p className="text-foreground font-bold text-sm">Ramadan Special Offers</p>
                  <p className="text-muted-foreground text-xs">Limited time discounts on all services</p>
                </div>
                <Star className="w-5 h-5 text-primary fill-primary" />
              </div>
            </div>
          </motion.div>

          <div className="inline-flex items-center gap-2 px-3 py-1 rounded-full bg-primary/10 text-primary text-sm font-medium mb-4">
            <Sparkles className="w-3.5 h-3.5" />
            Pricing
          </div>
          <h2 className="text-4xl md:text-5xl font-display font-bold mb-4">
            Choose Your <span className="text-gradient-blue">Service</span>
          </h2>
          <p className="text-muted-foreground max-w-lg mx-auto">
            Three service tiers. Prices vary by car type and condition.
          </p>
        </motion.div>

        <div className="grid grid-cols-1 md:grid-cols-3 gap-6 max-w-5xl mx-auto">
          {services.map((svc, i) => (
            <motion.div
              key={svc.name}
              initial={{ opacity: 0, y: 20 }}
              whileInView={{ opacity: 1, y: 0 }}
              viewport={{ once: true }}
              transition={{ delay: i * 0.1 }}
              className={`relative rounded-2xl border overflow-hidden transition-all duration-300 hover:scale-[1.02] group ${
                svc.popular
                  ? "bg-card border-primary shadow-blue"
                  : "bg-card border-border hover:border-primary/30 shadow-soft"
              }`}
            >
              {svc.popular && (
                <span className="absolute top-4 right-4 z-20 px-3 py-1 bg-gradient-blue text-primary-foreground text-xs font-bold rounded-full uppercase tracking-wider">
                  Best Value
                </span>
              )}

              {/* Image */}
              <div className="relative h-40 overflow-hidden">
                <img
                  src={svc.image}
                  alt={svc.name}
                  className="w-full h-full object-cover group-hover:scale-110 transition-transform duration-500"
                />
                <div className="absolute inset-0 bg-gradient-to-t from-card via-card/50 to-transparent" />
                {/* Discount badge on image */}
                <div className="absolute top-3 left-3 px-3 py-1 rounded-full bg-destructive/90 backdrop-blur-sm">
                  <span className="text-destructive-foreground text-xs font-bold">{svc.discount}</span>
                </div>
              </div>

              <div className="p-6">
                <h3 className="text-lg font-display font-semibold text-foreground mb-1">{svc.name}</h3>
                <p className="text-muted-foreground text-xs mb-4">{svc.desc}</p>

                {/* Prices by type */}
                <div className="space-y-2 mb-5">
                  {sizeLabels.map((size) => (
                    <div key={size.key} className="flex justify-between items-center text-sm">
                      <span className="text-muted-foreground text-xs">{size.label}</span>
                      <div className="flex items-center gap-2">
                        <span className="text-muted-foreground line-through text-[10px]">
                          {svc.originalPrices[size.key as keyof typeof svc.originalPrices]}
                        </span>
                        <span className="font-display font-bold text-foreground text-xs">
                          {svc.prices[size.key as keyof typeof svc.prices]}
                        </span>
                      </div>
                    </div>
                  ))}
                </div>

                {/* Features */}
                <p className="text-xs font-medium text-muted-foreground uppercase tracking-wider mb-3">Includes:</p>
                <div className="space-y-1.5">
                  {svc.features.map((f) => (
                    <div key={f} className="flex items-start gap-2">
                      <div className="w-4 h-4 rounded-full bg-accent/10 flex items-center justify-center flex-shrink-0 mt-0.5">
                        <Check className="w-2.5 h-2.5 text-accent" />
                      </div>
                      <span className="text-foreground text-xs">{f}</span>
                    </div>
                  ))}
                </div>

                <a
                  href="#booking"
                  className={`mt-5 block text-center px-6 py-3 rounded-full font-semibold text-sm transition-all hover:scale-105 ${
                    svc.popular
                      ? "bg-gradient-blue text-primary-foreground shadow-blue"
                      : "border border-border text-foreground hover:border-primary/30"
                  }`}
                >
                  Book Now
                </a>
              </div>
            </motion.div>
          ))}
        </div>

        {/* Add-ons */}
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true }}
          className="max-w-md mx-auto mt-10 bg-card rounded-2xl border border-border shadow-soft p-6"
        >
          <div className="flex items-center justify-center gap-2 mb-4">
            <Tag className="w-4 h-4 text-primary" />
            <h4 className="text-lg font-display font-bold text-foreground">Add-Ons</h4>
          </div>
          <div className="space-y-3">
            {addOns.map((addon) => (
              <div key={addon.name} className="flex items-center justify-between py-2 border-b border-border last:border-0">
                <div className="flex items-center gap-2">
                  <span className="text-sm text-foreground">{addon.name}</span>
                  {addon.hasFaqLink && (
                    <a href="#faq" className="inline-flex items-center gap-0.5 text-primary text-[10px] font-medium hover:underline">
                      What's this? <ArrowRight className="w-2.5 h-2.5" />
                    </a>
                  )}
                </div>
                <div className="flex items-center gap-2">
                  <span className="text-muted-foreground line-through text-xs">{addon.originalPrice}</span>
                  <span className="font-display font-bold text-foreground">{addon.price}</span>
                </div>
              </div>
            ))}
          </div>
        </motion.div>

        <p className="text-center text-muted-foreground text-xs mt-8">
          Final price depends on car condition, dirtiness level, and specific requirements.
        </p>
      </div>
    </section>
  );
};

export default Pricing;
