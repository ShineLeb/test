import { motion } from "framer-motion";
import { Droplets, SprayCan, Car, Sparkles, Wind, ShieldCheck } from "lucide-react";

const services = [
  { icon: SprayCan, title: "Interior Detailing", desc: "Deep cleaning of seats, dashboard, carpets & more" },
  { icon: Droplets, title: "Exterior Wash & Detail", desc: "Hand wash, rims, tires & full exterior clean" },
  { icon: Car, title: "Tire & Rim Cleaning", desc: "Deep clean and shine for wheels and rims" },
  { icon: Wind, title: "Air Freshening", desc: "Interior deodorizing for a fresh, clean scent" },
  { icon: ShieldCheck, title: "Surface Protection", desc: "Dashboard & trim conditioning for lasting shine" },
  { icon: Sparkles, title: "Final Inspection", desc: "Quality check to ensure showroom-level finish" },
];

const Services = () => {
  return (
    <section className="py-24 bg-background relative overflow-hidden" id="services">
      <div className="absolute top-10 right-10 w-32 h-32 rounded-full bg-primary/5 blur-2xl" />
      <div className="absolute bottom-20 left-5 w-24 h-24 rounded-full bg-accent/5 blur-xl" />
      <motion.div
        className="absolute bottom-10 right-1/4 w-5 h-5 rounded-full bg-primary/10"
        animate={{ scale: [1, 1.5, 1], opacity: [0.2, 0.5, 0.2] }}
        transition={{ duration: 3, repeat: Infinity }}
      />
      <motion.div
        className="absolute top-1/3 left-[5%] w-8 h-8 rounded-full border-2 border-dashed border-primary/10"
        animate={{ rotate: [0, 360] }}
        transition={{ duration: 10, repeat: Infinity, ease: "linear" }}
      />
      <div className="absolute top-0 left-0 right-0 h-px bg-gradient-to-r from-transparent via-primary/20 to-transparent" />

      <div className="container mx-auto px-6 relative z-10">
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true }}
          className="text-center mb-16"
        >
          <div className="inline-flex items-center gap-2 px-3 py-1 rounded-full bg-primary/10 text-primary text-sm font-medium mb-4">
            <Droplets className="w-3.5 h-3.5" />
            What We Do
          </div>
          <h2 className="text-4xl md:text-5xl font-display font-bold mb-4">
            Three Services. <span className="text-gradient-blue">Total Coverage.</span>
          </h2>
          <p className="text-muted-foreground max-w-lg mx-auto">
            Choose from Interior, Exterior, or Full Detail — we bring everything to your doorstep anywhere in Lebanon.
          </p>
        </motion.div>

        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
          {services.map((service, i) => (
            <motion.div
              key={service.title}
              initial={{ opacity: 0, y: 20 }}
              whileInView={{ opacity: 1, y: 0 }}
              viewport={{ once: true }}
              transition={{ delay: i * 0.1 }}
              className="group p-6 rounded-2xl bg-card border border-border hover:border-primary/30 hover:shadow-soft transition-all duration-300"
            >
              <div className="w-12 h-12 rounded-xl bg-gradient-blue flex items-center justify-center mb-4 group-hover:scale-110 transition-transform">
                <service.icon className="w-6 h-6 text-primary-foreground" />
              </div>
              <h3 className="text-lg font-display font-semibold text-foreground mb-2">{service.title}</h3>
              <p className="text-muted-foreground text-sm">{service.desc}</p>
            </motion.div>
          ))}
        </div>

        <motion.div
          initial={{ opacity: 0, y: 20 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true }}
          className="text-center mt-12"
        >
          <a
            href="#pricing"
            className="inline-flex items-center justify-center gap-2 px-8 py-4 bg-gradient-blue text-primary-foreground font-semibold rounded-full shadow-blue hover:scale-105 transition-transform"
          >
            <Droplets className="w-5 h-5" />
            See Pricing
          </a>
        </motion.div>
      </div>
    </section>
  );
};

export default Services;
