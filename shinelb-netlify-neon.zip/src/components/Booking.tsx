import { useState, useMemo } from "react";
import { motion } from "framer-motion";
import { format } from "date-fns";
import { CalendarIcon, CheckCircle2, Droplets, Sparkles, Zap, DollarSign, Clock } from "lucide-react";
import { cn } from "@/lib/utils";
import { Calendar } from "@/components/ui/calendar";
import {
  Popover,
  PopoverContent,
  PopoverTrigger,
} from "@/components/ui/popover";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import { Input } from "@/components/ui/input";
import { Textarea } from "@/components/ui/textarea";
import { Checkbox } from "@/components/ui/checkbox";
import { useToast } from "@/hooks/use-toast";
import { carBrands, getCarType, getCarTypeLabel } from "@/lib/carData";
import { calculateEstimatedPrice } from "@/lib/pricing";
import { submitBooking } from "@/lib/api";

const serviceTypes = [
  { value: "interior", label: "Interior Detailing", desc: "Deep clean seats, dashboard, carpets & air freshening" },
  { value: "exterior", label: "Exterior Wash & Detail", desc: "Hand wash, light polish, tire & rim cleaning" },
  { value: "full", label: "Full Detail", desc: "Complete interior + exterior for a showroom finish" },
];

const dirtinessLevels = [
  { value: "1", label: "Light", emoji: "✨" },
  { value: "2", label: "Moderate", emoji: "💧" },
  { value: "3", label: "Heavy", emoji: "🤮" },
];

const timeSlots = [
  "8:00 AM", "8:30 AM", "9:00 AM", "9:30 AM", "10:00 AM", "10:30 AM",
  "11:00 AM", "11:30 AM", "12:00 PM", "12:30 PM", "1:00 PM", "1:30 PM",
  "2:00 PM", "2:30 PM", "3:00 PM", "3:30 PM", "4:00 PM", "4:30 PM",
  "5:00 PM", "5:30 PM", "6:00 PM", "6:30 PM", "7:00 PM", "7:30 PM", "8:00 PM",
];

const Booking = () => {
  const [date, setDate] = useState<Date>();
  const [time, setTime] = useState("");
  const [brand, setBrand] = useState("");
  const [model, setModel] = useState("");
  const [service, setService] = useState("");
  const [dirtiness, setDirtiness] = useState("");
  const [petHair, setPetHair] = useState(false);
  const [ceramicSpray, setCeramicSpray] = useState(false);
  const [headlightRestoration, setHeadlightRestoration] = useState(false);
  const [hasOutlet, setHasOutlet] = useState<string>("");
  const [name, setName] = useState("");
  const [location, setLocation] = useState("");
  const [notes, setNotes] = useState("");
  const [submitted, setSubmitted] = useState(false);
  const { toast } = useToast();

  const models = useMemo(() => (brand ? carBrands[brand] || [] : []), [brand]);
  const selectedService = serviceTypes.find((s) => s.value === service);

  const carType = useMemo(() => {
    if (brand && model) return getCarType(brand, model);
    return null;
  }, [brand, model]);

  const estimatedPrice = useMemo(() => {
    if (!carType || !service || !dirtiness) return null;
    return calculateEstimatedPrice(carType, service, parseInt(dirtiness), {
      petHair,
      ceramicSpray,
      headlightRestoration,
    });
  }, [carType, service, dirtiness, petHair, ceramicSpray, headlightRestoration]);

  // Disable Sundays
  const disableDate = (d: Date) => {
    return d < new Date() || d.getDay() === 0;
  };

  const handleBook = async () => {
    if (!name.trim() || !date || !time || !brand || !model || !service || !location.trim() || !dirtiness) {
      toast({
        title: "Missing info",
        description: "Please fill in all required fields.",
        variant: "destructive",
      });
      return;
    }

    try {
      await submitBooking({
        name: name.trim(),
        brand,
        model,
        service,
        dirtiness: parseInt(dirtiness),
        date: date.toISOString(),
        time,
        location: location.trim(),
        notes: notes.trim() || undefined,
        addons: { petHair, ceramicSpray, headlightRestoration, hasOutlet },
        estimatedPrice: estimatedPrice ?? null,
      });
    } catch (e: any) {
      toast({ title: "Error", description: "Could not submit booking. Please try again.", variant: "destructive" });
      return;
    }

    setSubmitted(true);
    toast({
      title: "Booking Confirmed!",
      description: `Thanks ${name.trim()}! We'll reach out to confirm your ${selectedService?.label} for your ${brand} ${model} on ${format(date, "PPP")} at ${time}.`,
    });
  };

  const handleReset = () => {
    setDate(undefined);
    setTime("");
    setBrand("");
    setModel("");
    setService("");
    setDirtiness("");
    setPetHair(false);
    setCeramicSpray(false);
    setHeadlightRestoration(false);
    setHasOutlet("");
    setName("");
    setLocation("");
    setNotes("");
    setSubmitted(false);
  };

  return (
    <section className="py-24 bg-primary/5 relative overflow-hidden" id="booking">
      {/* Decorative elements */}
      <div className="absolute top-10 left-10 w-20 h-20 rounded-full bg-primary/10 blur-xl" />
      <div className="absolute bottom-20 right-10 w-28 h-28 rounded-full bg-accent/10 blur-xl" />
      <motion.div
        className="absolute top-1/3 right-1/4 w-6 h-6 rounded-full border-2 border-dashed border-primary/20"
        animate={{ x: [0, 8, -8, 0] }}
        transition={{ duration: 4, repeat: Infinity, ease: "easeInOut" }}
      />
      <motion.div
        className="absolute bottom-1/3 left-1/4 w-4 h-4 rounded-full bg-primary/20"
        animate={{ y: [0, -20, 0], opacity: [0.3, 0.7, 0.3] }}
        transition={{ duration: 5, repeat: Infinity }}
      />
      {/* Top/bottom accent lines */}
      <div className="absolute top-0 left-0 right-0 h-px bg-gradient-to-r from-transparent via-primary/20 to-transparent" />

      <div className="container mx-auto px-6 relative z-10">
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true }}
          className="text-center mb-12"
        >
          <div className="inline-flex items-center gap-2 px-3 py-1 rounded-full bg-primary/10 text-primary text-sm font-medium mb-4">
            <Sparkles className="w-3.5 h-3.5" />
            Book Now
          </div>
          <h2 className="text-4xl md:text-5xl font-display font-bold mb-4">
            Reserve Your <span className="text-gradient-blue">Spot</span>
          </h2>
          <p className="text-muted-foreground max-w-lg mx-auto">
            Pick your date, tell us where you are, and we'll come to you.
          </p>
        </motion.div>

        {submitted ? (
          <motion.div
            initial={{ opacity: 0, scale: 0.95 }}
            animate={{ opacity: 1, scale: 1 }}
            className="max-w-lg mx-auto text-center py-16"
          >
            <div className="w-20 h-20 mx-auto rounded-full bg-accent/10 flex items-center justify-center mb-6">
              <CheckCircle2 className="w-10 h-10 text-accent" />
            </div>
            <h3 className="text-2xl font-display font-bold text-foreground mb-3">Booking Received!</h3>
            <p className="text-muted-foreground mb-2">
              <strong>{name.trim()}</strong> — {brand} {model}
              {carType && <span className="text-xs ml-2 text-primary">({getCarTypeLabel(carType)})</span>}
            </p>
            <p className="text-muted-foreground mb-1">{selectedService?.label}</p>
            <p className="text-muted-foreground mb-1">Dirtiness: {dirtiness}/3</p>
            {petHair && <p className="text-muted-foreground mb-1">+ Pet Hair Removal</p>}
            {ceramicSpray && <p className="text-muted-foreground mb-1">+ Ceramic Spray Protection</p>}
            {headlightRestoration && <p className="text-muted-foreground mb-1">+ Headlight Restoration</p>}
            {estimatedPrice !== null && (
              <p className="text-lg font-display font-bold text-foreground mb-1">
                Estimated: ~${estimatedPrice}
              </p>
            )}
            <p className="text-muted-foreground mb-1">{date && format(date, "PPP")} at {time}</p>
            <p className="text-muted-foreground mb-6">{location.trim()}</p>
            <p className="text-sm text-muted-foreground mb-8">
              We'll contact you shortly on WhatsApp or by phone to confirm. Final price may vary slightly after inspection but always within the listed range.
            </p>
            <button
              onClick={handleReset}
              className="px-6 py-3 rounded-full border border-border text-foreground font-medium hover:bg-card transition-colors"
            >
              Book Another
            </button>
          </motion.div>
        ) : (
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true }}
            className="max-w-lg mx-auto"
          >
            <div className="bg-card rounded-2xl shadow-soft border border-border p-6 sm:p-8 space-y-5">
              {/* Name */}
              <div>
                <label className="block text-sm font-medium text-foreground mb-1.5">Your Name</label>
                <Input placeholder="Enter your name" value={name} onChange={(e) => setName(e.target.value)} maxLength={100} className="rounded-xl" />
              </div>

              {/* Date Picker */}
              <div>
                <label className="block text-sm font-medium text-foreground mb-1.5">Preferred Date</label>
                <Popover>
                  <PopoverTrigger asChild>
                    <button className={cn("w-full flex items-center gap-2 px-3 py-2.5 rounded-xl border border-input bg-background text-sm text-left transition-colors hover:border-primary/50", !date && "text-muted-foreground")}>
                      <CalendarIcon className="w-4 h-4 text-primary" />
                      {date ? format(date, "PPP") : "Pick a date (Mon–Sat)"}
                    </button>
                  </PopoverTrigger>
                  <PopoverContent className="w-auto p-0" align="start">
                    <Calendar mode="single" selected={date} onSelect={setDate} disabled={disableDate} initialFocus className="p-3 pointer-events-auto" />
                  </PopoverContent>
                </Popover>
              </div>

              {/* Time Picker */}
              <div>
                <label className="block text-sm font-medium text-foreground mb-1.5">
                  <span className="flex items-center gap-1.5">
                    <Clock className="w-3.5 h-3.5 text-primary" />
                    Preferred Time
                  </span>
                </label>
                <Select value={time} onValueChange={setTime}>
                  <SelectTrigger className="rounded-xl">
                    <SelectValue placeholder="Select time (8 AM – 8 PM)" />
                  </SelectTrigger>
                  <SelectContent className="max-h-60">
                    {timeSlots.map((t) => (
                      <SelectItem key={t} value={t}>{t}</SelectItem>
                    ))}
                  </SelectContent>
                </Select>
                <p className="text-xs text-muted-foreground mt-1">Working hours: Monday – Saturday, 8 AM – 8 PM</p>
              </div>

              {/* Car Brand */}
              <div>
                <label className="block text-sm font-medium text-foreground mb-1.5">Car Brand</label>
                <Select value={brand} onValueChange={(v) => { setBrand(v); setModel(""); }}>
                  <SelectTrigger className="rounded-xl">
                    <SelectValue placeholder="Select car brand" />
                  </SelectTrigger>
                  <SelectContent className="max-h-60">
                    {Object.keys(carBrands).sort().map((b) => (
                      <SelectItem key={b} value={b}>{b}</SelectItem>
                    ))}
                  </SelectContent>
                </Select>
              </div>

              {/* Car Model */}
              {brand && (
                <div>
                  <label className="block text-sm font-medium text-foreground mb-1.5">Car Model</label>
                  <Select value={model} onValueChange={setModel}>
                    <SelectTrigger className="rounded-xl">
                      <SelectValue placeholder="Select model" />
                    </SelectTrigger>
                    <SelectContent className="max-h-60">
                      {models.map((m) => (
                        <SelectItem key={m} value={m}>{m}</SelectItem>
                      ))}
                    </SelectContent>
                  </Select>
                  {carType && (
                    <p className="text-xs text-primary mt-1.5 font-medium">
                      Auto-detected: {getCarTypeLabel(carType)}
                    </p>
                  )}
                </div>
              )}

              {/* Service Type */}
              <div>
                <label className="block text-sm font-medium text-foreground mb-1.5">Service Type</label>
                <Select value={service} onValueChange={setService}>
                  <SelectTrigger className="rounded-xl">
                    <SelectValue placeholder="Select service" />
                  </SelectTrigger>
                  <SelectContent>
                    {serviceTypes.map((s) => (
                      <SelectItem key={s.value} value={s.value}>
                        {s.label}
                      </SelectItem>
                    ))}
                  </SelectContent>
                </Select>
                {selectedService && (
                  <p className="text-xs text-muted-foreground mt-1.5">{selectedService.desc}</p>
                )}
              </div>

              {/* Dirtiness Scale */}
              <div>
                <label className="block text-sm font-medium text-foreground mb-2">How dirty is your car?</label>
                <div className="grid grid-cols-3 gap-2">
                  {dirtinessLevels.map((level) => (
                    <button
                      key={level.value}
                      type="button"
                      onClick={() => setDirtiness(level.value)}
                      className={cn(
                        "py-3 rounded-xl border text-sm font-medium transition-all duration-200 flex flex-col items-center gap-1",
                        dirtiness === level.value
                          ? "border-primary bg-primary/10 text-foreground scale-105 shadow-sm"
                          : "border-border bg-background text-muted-foreground hover:border-primary/30 hover:bg-primary/5"
                      )}
                    >
                      <span className="text-lg">{level.emoji}</span>
                      <span className="text-xs">{level.label}</span>
                    </button>
                  ))}
                </div>
              </div>

              {/* Add-ons */}
              <div>
                <label className="block text-sm font-medium text-foreground mb-3">Add-Ons</label>
                <div className="space-y-3">
                  <label className="flex items-center gap-3 p-3 rounded-xl border border-border bg-background hover:border-primary/30 transition-colors cursor-pointer">
                    <Checkbox checked={petHair} onCheckedChange={(v) => setPetHair(v === true)} />
                    <div className="flex-1 flex flex-wrap items-center gap-x-2">
                      <span className="text-sm font-medium text-foreground">Pet Hair Removal</span>
                      <span className="text-xs text-muted-foreground">$22.99</span>
                    </div>
                  </label>
                  <label className="flex items-center gap-3 p-3 rounded-xl border border-border bg-background hover:border-primary/30 transition-colors cursor-pointer">
                    <Checkbox checked={ceramicSpray} onCheckedChange={(v) => setCeramicSpray(v === true)} />
                    <div className="flex-1 flex flex-wrap items-center gap-x-2">
                      <span className="text-sm font-medium text-foreground">Ceramic Spray Protection</span>
                      <span className="text-xs text-muted-foreground">$32.99</span>
                      <a href="#faq" className="text-primary text-[10px] font-medium hover:underline ml-1">Learn more</a>
                    </div>
                  </label>
                  <label className="flex items-center gap-3 p-3 rounded-xl border border-border bg-background hover:border-primary/30 transition-colors cursor-pointer">
                    <Checkbox checked={headlightRestoration} onCheckedChange={(v) => setHeadlightRestoration(v === true)} />
                    <div className="flex-1 flex flex-wrap items-center gap-x-2">
                      <span className="text-sm font-medium text-foreground">Headlight Restoration</span>
                      <span className="text-xs text-muted-foreground">$34.99</span>
                    </div>
                  </label>
                </div>
              </div>

              {/* Power Outlet */}
              <div>
                <label className="block text-sm font-medium text-foreground mb-2">
                  Is there a power outlet nearby?
                </label>
                <p className="text-xs text-muted-foreground mb-2">
                  Not required — but it helps us work faster if there's one close by!
                </p>
                <div className="flex gap-3">
                  <button
                    type="button"
                    onClick={() => setHasOutlet("yes")}
                    className={cn(
                      "flex-1 py-2.5 rounded-xl border text-sm font-medium transition-all flex items-center justify-center gap-2",
                      hasOutlet === "yes"
                        ? "border-primary bg-primary/10 text-foreground"
                        : "border-border bg-background text-muted-foreground hover:border-primary/30"
                    )}
                  >
                    <Zap className="w-3.5 h-3.5" />
                    Yes
                  </button>
                  <button
                    type="button"
                    onClick={() => setHasOutlet("no")}
                    className={cn(
                      "flex-1 py-2.5 rounded-xl border text-sm font-medium transition-all",
                      hasOutlet === "no"
                        ? "border-primary bg-primary/10 text-foreground"
                        : "border-border bg-background text-muted-foreground hover:border-primary/30"
                    )}
                  >
                    No
                  </button>
                </div>
              </div>

              {/* Location */}
              <div>
                <label className="block text-sm font-medium text-foreground mb-1.5">Your Location</label>
                <Input placeholder="e.g. Beirut, Jounieh, Tripoli..." value={location} onChange={(e) => setLocation(e.target.value)} maxLength={200} className="rounded-xl" />
              </div>

              {/* Notes */}
              <div>
                <label className="block text-sm font-medium text-foreground mb-1.5">
                  Notes <span className="text-muted-foreground">(optional)</span>
                </label>
                <Textarea placeholder="Any special requests or details..." value={notes} onChange={(e) => setNotes(e.target.value)} maxLength={500} rows={3} className="rounded-xl resize-none" />
              </div>

              {/* Estimated Price Display */}
              {estimatedPrice !== null && (
                <motion.div
                  initial={{ opacity: 0, y: 10 }}
                  animate={{ opacity: 1, y: 0 }}
                  className="p-4 rounded-xl bg-primary/5 border border-primary/20"
                >
                  <div className="flex items-center justify-between">
                    <div className="flex items-center gap-2">
                      <DollarSign className="w-5 h-5 text-primary" />
                      <span className="text-sm font-medium text-foreground">Estimated Price</span>
                    </div>
                    <span className="text-2xl font-display font-bold text-gradient-blue">${estimatedPrice}</span>
                  </div>
                  <p className="text-xs text-muted-foreground mt-2">
                    We need to inspect the car before giving a final price, but it will always be within the listed range for your vehicle type.
                  </p>
                </motion.div>
              )}

              {/* Submit */}
              <button
                onClick={handleBook}
                className="w-full flex items-center justify-center gap-2 px-8 py-4 bg-gradient-blue text-primary-foreground font-semibold rounded-full shadow-blue hover:scale-[1.02] active:scale-100 transition-transform duration-200"
              >
                <Droplets className="w-4 h-4" />
                Book Now
              </button>
            </div>

            <p className="text-center text-muted-foreground text-xs mt-4">
              We'll confirm your booking via WhatsApp or phone call.
            </p>
          </motion.div>
        )}
      </div>
    </section>
  );
};

export default Booking;
