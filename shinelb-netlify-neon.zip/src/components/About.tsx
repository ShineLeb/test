import { motion } from "framer-motion";
import { Droplets, MapPin, Car, Sparkles, Clock, Shield } from "lucide-react";

const stats = [
  { icon: Car, value: "100+", label: "Cars Detailed" },
  { icon: MapPin, value: "All Lebanon", label: "We Come to You" },
  { icon: Sparkles, value: "5★", label: "Customer Rating" },
  { icon: Clock, value: "Mon–Sat", label: "8 AM – 8 PM" },
];

const About = () => {
  return (
    <section className="py-24 bg-card relative overflow-hidden" id="about">
      {/* Decorative */}
      <div className="absolute top-10 right-10 w-24 h-24 rounded-full bg-primary/5 blur-2xl" />
      <div className="absolute bottom-10 left-10 w-20 h-20 rounded-full bg-accent/5 blur-xl" />
      <motion.div
        className="absolute top-1/2 left-10 w-6 h-6 rounded-full border-2 border-dashed border-primary/15"
        animate={{ x: [0, 8, -8, 0] }}
        transition={{ duration: 4, repeat: Infinity, ease: "easeInOut" }}
      />
      <motion.div
        className="absolute top-20 right-1/4 w-4 h-4 rounded-full bg-primary/15"
        animate={{ y: [0, -12, 0], opacity: [0.3, 0.6, 0.3] }}
        transition={{ duration: 3, repeat: Infinity }}
      />
      <div className="absolute top-0 left-0 right-0 h-px bg-gradient-to-r from-transparent via-primary/20 to-transparent" />

      <div className="container mx-auto px-6 relative z-10">
        <div className="grid grid-cols-1 lg:grid-cols-2 gap-16 items-center max-w-5xl mx-auto">
          {/* Left: stats grid */}
          <motion.div
            initial={{ opacity: 0, x: -30 }}
            whileInView={{ opacity: 1, x: 0 }}
            viewport={{ once: true }}
            className="relative"
          >
            <div className="grid grid-cols-2 gap-4">
              {stats.map((stat, i) => (
                <motion.div
                  key={stat.label}
                  initial={{ opacity: 0, y: 20 }}
                  whileInView={{ opacity: 1, y: 0 }}
                  viewport={{ once: true }}
                  transition={{ delay: i * 0.1 }}
                  className="p-5 rounded-2xl bg-background border border-border hover:border-primary/20 transition-colors group"
                >
                  <div className="w-12 h-12 rounded-xl bg-primary/10 flex items-center justify-center mb-3 group-hover:scale-110 transition-transform">
                    <stat.icon className="w-6 h-6 text-primary" />
                  </div>
                  <p className="text-2xl font-display font-bold text-gradient-blue">{stat.value}</p>
                  <p className="text-muted-foreground text-sm">{stat.label}</p>
                </motion.div>
              ))}
            </div>
            {/* Floating accent */}
            <div className="absolute -bottom-4 -right-4 w-16 h-16 rounded-full bg-accent/20 blur-sm" />
          </motion.div>

          {/* Right: text */}
          <motion.div
            initial={{ opacity: 0, x: 30 }}
            whileInView={{ opacity: 1, x: 0 }}
            viewport={{ once: true }}
          >
            <div className="inline-flex items-center gap-2 px-3 py-1 rounded-full bg-primary/10 text-primary text-sm font-medium mb-4">
              <Droplets className="w-3.5 h-3.5" />
              About Us
            </div>
            <h2 className="text-4xl md:text-5xl font-display font-bold mb-6">
              What is <span className="text-gradient-blue">ShineLeb?</span>
            </h2>
            <p className="text-muted-foreground leading-relaxed mb-4">
              ShineLeb is Lebanon's premier mobile car detailing service. We bring professional-grade cleaning, polishing, and protection directly to your doorstep — whether you're at home, work, or anywhere else.
            </p>
            <p className="text-muted-foreground leading-relaxed mb-4">
              Our team of experienced detailers use premium products and equipment to deliver a showroom-quality finish every time. From sedans to SUVs to 4x4 trucks — we handle it all.
            </p>
            <p className="text-muted-foreground leading-relaxed mb-8">
              Open Monday through Saturday, 8 AM to 8 PM. Choose from Interior, Exterior, or Full Detail packages with optional add-ons like Ceramic Spray Protection and Headlight Restoration.
            </p>
            <div className="flex flex-wrap gap-4">
              <a
                href="#booking"
                className="inline-flex items-center justify-center gap-2 px-7 py-3.5 bg-gradient-blue text-primary-foreground font-semibold rounded-full shadow-blue hover:scale-105 transition-transform"
              >
                <Droplets className="w-4 h-4" />
                Book Now
              </a>
              <a
                href="#services"
                className="inline-flex items-center justify-center px-7 py-3.5 border border-border text-foreground font-semibold rounded-full hover:bg-primary/5 transition-colors"
              >
                See What's Included
              </a>
            </div>
          </motion.div>
        </div>
      </div>
    </section>
  );
};

export default About;
