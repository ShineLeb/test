import { motion } from "framer-motion";
import { MapPin, Clock, Shield, Droplets, Sparkles } from "lucide-react";

const reasons = [
  {
    icon: MapPin,
    title: "We Come to You",
    desc: "Anywhere in Lebanon — home, office, or wherever your car is parked.",
  },
  {
    icon: Clock,
    title: "Save Your Time",
    desc: "No driving to the shop. We handle everything while you go about your day.",
  },
  {
    icon: Shield,
    title: "Premium Quality",
    desc: "Professional-grade products and experienced detailers for a showroom finish.",
  },
];

const WhyUs = () => {
  return (
    <section className="py-24 bg-background relative overflow-hidden">
      {/* Decorative circles */}
      <div className="absolute -top-10 -right-10 w-48 h-48 rounded-full border-4 border-dashed border-primary/10" />
      <div className="absolute bottom-10 -left-8 w-32 h-32 rounded-full border-4 border-dashed border-accent/10" />
      <motion.div
        className="absolute top-1/4 left-[8%] w-5 h-5 rounded-full bg-primary/15"
        animate={{ y: [0, -15, 0], opacity: [0.2, 0.5, 0.2] }}
        transition={{ duration: 4, repeat: Infinity }}
      />
      <motion.div
        className="absolute bottom-1/4 right-[12%] w-4 h-4 rounded-full bg-accent/15"
        animate={{ scale: [1, 1.4, 1], opacity: [0.2, 0.4, 0.2] }}
        transition={{ duration: 3, repeat: Infinity, delay: 1 }}
      />
      <div className="absolute top-0 left-0 right-0 h-px bg-gradient-to-r from-transparent via-primary/20 to-transparent" />

      <div className="container mx-auto px-6 relative z-10">
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true }}
          className="text-center mb-16"
        >
          <div className="inline-flex items-center gap-2 px-3 py-1 rounded-full bg-primary/10 text-primary text-sm font-medium mb-4">
            <Sparkles className="w-3.5 h-3.5" />
            Why Choose Us
          </div>
          <h2 className="text-4xl md:text-5xl font-display font-bold">
            The <span className="text-gradient-blue">Easiest</span> Way
          </h2>
        </motion.div>

        <div className="grid grid-cols-1 md:grid-cols-3 gap-8 max-w-4xl mx-auto">
          {reasons.map((reason, i) => (
            <motion.div
              key={reason.title}
              initial={{ opacity: 0, y: 20 }}
              whileInView={{ opacity: 1, y: 0 }}
              viewport={{ once: true }}
              transition={{ delay: i * 0.15 }}
              className="text-center p-6 rounded-2xl hover:bg-card hover:shadow-soft transition-all duration-300"
            >
              <div className="w-16 h-16 mx-auto rounded-2xl bg-gradient-blue flex items-center justify-center mb-5">
                <reason.icon className="w-7 h-7 text-primary-foreground" />
              </div>
              <h3 className="text-xl font-display font-semibold text-foreground mb-2">{reason.title}</h3>
              <p className="text-muted-foreground text-sm leading-relaxed">{reason.desc}</p>
            </motion.div>
          ))}
        </div>

        <motion.div
          initial={{ opacity: 0, y: 20 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true }}
          className="text-center mt-12"
        >
          <a
            href="#booking"
            className="inline-flex items-center justify-center gap-2 px-8 py-4 bg-gradient-blue text-primary-foreground font-semibold rounded-full shadow-blue hover:scale-105 transition-transform"
          >
            <Droplets className="w-5 h-5" />
            Get Started
          </a>
        </motion.div>
      </div>
    </section>
  );
};

export default WhyUs;
