export type Review = {
  id: string;
  name: string;
  rating: number;
  review: string;
  created_at: string;
};

export type BookingPayload = {
  name: string;
  phone?: string;
  brand: string;
  model: string;
  service: string;
  dirtiness: number;
  date: string;      // ISO date
  time: string;      // display string
  location: string;
  notes?: string;
  addons: {
    petHair: boolean;
    ceramicSpray: boolean;
    headlightRestoration: boolean;
    hasOutlet?: string;
  };
  estimatedPrice?: number | null;
};

export async function fetchReviews(): Promise<Review[]> {
  const res = await fetch("/.netlify/functions/reviews", { method: "GET" });
  if (!res.ok) throw new Error("Failed to load reviews");
  return await res.json();
}

export async function submitReview(payload: { name: string; rating: number; review: string }) {
  const res = await fetch("/.netlify/functions/reviews", {
    method: "POST",
    headers: { "Content-Type": "application/json" },
    body: JSON.stringify(payload),
  });
  if (!res.ok) throw new Error("Failed to submit review");
  return await res.json();
}

export async function submitBooking(payload: BookingPayload) {
  const res = await fetch("/.netlify/functions/bookings", {
    method: "POST",
    headers: { "Content-Type": "application/json" },
    body: JSON.stringify(payload),
  });
  if (!res.ok) {
    const msg = await res.text();
    throw new Error(msg || "Failed to submit booking");
  }
  return await res.json();
}
