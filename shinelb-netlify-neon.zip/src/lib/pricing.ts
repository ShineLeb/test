import type { CarType } from "./carData";

// Price ranges [min, max] in USD (new pricing)
const servicePrices: Record<CarType, Record<string, [number, number]>> = {
  sedan: { interior: [62.99, 82.99], exterior: [32.99, 52.99], full: [84.99, 104.99] },
  suv: { interior: [82.99, 102.99], exterior: [42.99, 62.99], full: [109.99, 129.99] },
  "4x4": { interior: [102.99, 120.99], exterior: [52.99, 72.99], full: [134.99, 154.99] },
};

const addOnPrices: Record<string, number> = {
  petHair: 22.99,
  ceramicSpray: 32.99,
  headlightRestoration: 34.99,
};

/**
 * Calculates estimated price based on car type, service, dirtiness (1-3), and add-ons.
 * Dirtiness 1 = cleanest (min price), 3 = dirtiest (max price).
 */
export function calculateEstimatedPrice(
  carType: CarType,
  service: string,
  dirtiness: number,
  addOns: { petHair: boolean; ceramicSpray: boolean; headlightRestoration: boolean }
): number {
  const [min, max] = servicePrices[carType]?.[service] || [0, 0];
  const factor = (dirtiness - 1) / 2; // 0, 0.5, 1
  let price = min + (max - min) * factor;

  if (addOns.petHair) price += addOnPrices.petHair;
  if (addOns.ceramicSpray) price += addOnPrices.ceramicSpray;
  if (addOns.headlightRestoration) price += addOnPrices.headlightRestoration;

  return Math.round(price * 100) / 100;
}
